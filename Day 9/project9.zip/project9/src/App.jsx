// src/App.js

import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [notes, setNotes] = useState([]);
  const [newNote, setNewNote] = useState('');

  useEffect(() => {
    // Load notes from local storage on component mount
    const storedNotes = JSON.parse(localStorage.getItem('notes')) || [];
    setNotes(storedNotes);
  }, []);

  useEffect(() => {
    // Save notes to local storage whenever 'notes' state changes
    localStorage.setItem('notes', JSON.stringify(notes));
  }, [notes]);

  const addNote = () => {
    if (newNote.trim() !== '') {
      setNotes([...notes, newNote]);
      setNewNote('');
    }
  };

  const deleteNote = (index) => {
    const updatedNotes = [...notes];
    updatedNotes.splice(index, 1);
    setNotes(updatedNotes);
  };

  return (
    <div className="container mx-auto mt-8 p-4">
      <h1 className="text-4xl font-bold mb-4">Notes App</h1>
      <div className="mb-4">
        <input
          type="text"
          placeholder="Add a new note..."
          value={newNote}
          onChange={(e) => setNewNote(e.target.value)}
          className="p-2 border border-gray-300 w-full"
        />
        <button
          onClick={addNote}
          className="mt-2 bg-blue-500 text-white py-2 px-4 rounded"
        >
          Add Note
        </button>
      </div>
      <ul>
        {notes.map((note, index) => (
          <li key={index} className="mb-2">
            {note}
            <button
              onClick={() => deleteNote(index)}
              className="ml-2 text-red-500"
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
